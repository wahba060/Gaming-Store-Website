


window.onload = function() {

    // var local1 = document.getElementById("gamename").innerHTML = localStorage.getItem("gamename"+0);
    
    

    originalDiv = document.getElementById("originalDiv");
    clonedOG = document.getElementById("originalDiv").cloneNode(true);

    
    originalDiv.parentNode.removeChild(originalDiv);
    for(i=0;i<parseInt(localStorage.getItem('itemCount'));i++){
        
       
        // var clonedDiv = document.getElementById("originalDiv").cloneNode(true);
        var clonedDiv = clonedOG.cloneNode(true);
        clonedDiv.id = "clonedDiv"+i

        if(localStorage.getItem("gamename" + i)){
            clonedDiv.querySelector("#gamename").innerHTML = localStorage.getItem("gamename" + i);
            clonedSection.appendChild(clonedDiv);
            
        }
        if(localStorage.getItem("gameprice" + i)){
            var gameprice = clonedDiv.querySelector("#gameprice");
            clonedDiv.querySelector("#gameprice").innerHTML = localStorage.getItem("gameprice" + i)+ '$';

            
        }
        if(localStorage.getItem("gamephoto" + i)){
            var gameImg = clonedDiv.querySelector("#gameimg");
             gameImg.src = localStorage.getItem("gamephoto"+i);
        }
}

    
}


// function remove(name) {

//     for(o=0;o<parseInt(localStorage.getItem('itemCount'));o++){
//     var removedGame = document.getElementById("clonedDiv"+o);



//         if(localStorage.getItem("gamename"+o)== name){
//             // var currentItemCount = parseInt(localStorage.getItem('itemCount'));

//             localStorage.removeItem("gamename"+o);
//             localStorage.removeItem("gameprice"+o);
//             localStorage.removeItem("gamephoto"+o);
//             removedGame.parentNode.removeChild(removedGame);
//             break;
//             // currentItemCount--;
//             // localStorage.setItem('itemCount', currentItemCount);


//         }

//     }
// console.log(document.getElementById("gamename").innerHTML);
// console.log(removedGame);
// }

function remove(element) {
    let clonedDiv = element.closest("[id^='clonedDiv']");
    let gameNameElement = clonedDiv.querySelector("#gamename");

    for (let o = 0; o < parseInt(localStorage.getItem('itemCount')); o++) {
        if (localStorage.getItem("gamename" + o) === gameNameElement.innerText) {
            localStorage.removeItem("gamename" + o);
            localStorage.removeItem("gameprice" + o);
            localStorage.removeItem("gamephoto" + o);
            clonedDiv.parentNode.removeChild(clonedDiv);
            break;
        }
    }
    console.log(gameNameElement.innerText);
    console.log(clonedDiv);
}












// location.reload();

// if(localStorage.getItem("gamename" + i)=='God of War'){
//     var gameImg = clonedDiv.querySelector("#gameimg");
// gameImg.src = "assets/godcd.jpg";
// }
// if(localStorage.getItem("gamename" + i)=='Alan Wake 2'){
//     var gameImg = clonedDiv.querySelector("#gameimg");
// gameImg.src = "assets/alancd.webp";
// }
// if(localStorage.getItem("gamename" + i)=='Horizon Forbidden West'){
//     var gameImg = clonedDiv.querySelector("#gameimg");
// gameImg.src = "assets/forbiddencd.jpg";
// }
// if(localStorage.getItem("gamename" + i)=='Marvel Spider Man 2'){
//     var gameImg = clonedDiv.querySelector("#gameimg");
// gameImg.src = "assets/spiderman.jpg";
// }







        // var clonedDiv = originalDiv.cloneNode(true); // true to clone all children recursively
        // var targetDiv = document.getElementById("targetDiv");
        // cloned.appendChild(clonedDiv);
        // document.getElementById("gamename").innerHTML = localStorage.getItem("gamename"+i);

        // paragraph.textContent = localStorage.getItem("gamename" + i); 
        // paragraph.appendChild(image);

        // document.getElementById("cart-items").appendChild(linebreak);