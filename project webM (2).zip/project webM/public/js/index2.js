



var i = 0;
var gamelist = [];

function cartAdd(productName,productPrice,productPhoto){
    var i = localStorage.getItem('itemCount') || 0;
    
    if(productName){ 
       
        localStorage.setItem("gamename"+i,productName);
        localStorage.setItem("gameprice"+i,productPrice);
        localStorage.setItem("gamephoto"+i,productPhoto);


        i++;
        localStorage.setItem('itemCount', i);
    }
}



async function cartAdd2(gameName, price, imageUrl) {
    const data = { gameName, price, imageUrl };
    
    try {
        const response = await fetch('/cartAdi', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });
        if (response.ok) {
            console.log('Game added to cart');
        } else {
            console.error('Failed to add game to cart');
        }
    } catch (error) {
        console.error('Error:', error);
    }
}
