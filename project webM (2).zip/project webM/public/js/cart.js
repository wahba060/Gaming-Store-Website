// const indexarray = require('./index2.js');
// var linebreak =  document.createElement("br");
// var paragrapgh =  document.createElement("p");

//   console.log(gamelist);
// const gamelist = [];

// function cartAdd(productName){
//   gamelist.push(productName);
//   console.log(productName);

// }


// window.onload = function() {
//     if (window.location.pathname.includes("cart.html")) {
//         for(i=0;i<gamelist.length;i++){
//             document.getElementById("cart-items").innerHTML += gamelist.getItem(i);
//             document.getElementById("cart-items").appendChild(linebreak);
//         } 
//         console.log('hi :)');

//     }

 

// }


var linebreak =  document.createElement("br");



window.onload = function() {
    for(i=0;i<localStorage.length;i++){
        var paragraph = document.createElement("div");
        var image = document.createElement("img");
        image.src = 'assets/slidedhow3.jpg';

        paragraph.classList.add("card");
        document.getElementById("cart-items").appendChild(paragraph);
         document.getElementById("cart-photos").appendChild(image);

        paragraph.textContent = localStorage.getItem("gamename" + i); 
        // paragraph.appendChild(image);

        document.getElementById("cart-items").appendChild(linebreak);
        


}
}

    //  document.getElementById("cart-items").innerHTML += localStorage.getItem("gamename"+i);
