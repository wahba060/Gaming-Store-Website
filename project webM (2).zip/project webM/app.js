const express = require("express");
const mongoose = require("mongoose");
const User = require("./models/users");
const Order = require("./models/orders");

const app = express();
var path = require('path');
const bodyParser = require('body-parser');

const connectionString = "mongodb+srv://wahba:hpAmPLFFOtZz3RxL@cluster0.0sveaon.mongodb.net/shop?retryWrites=true&w=majority&appName=Cluster0"

mongoose.connect(connectionString)
    // .then((result)=>{app.listen(3000); console.log("Server is running");})
    .catch((err)=>{ console.log("Failed to connect to db"); console.log(err);});


    app.listen(3000, () => {
        console.log("Server is running on port 3000");
    });
app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname,'public')))
app.use((req, res, next)=>{
    console.log("a request is made");
    next();
});

app.use((req, res, next)=>{
    console.log(req.url);
    next();
});

app.get("/", (req, res)=>{
    res.status(200);
  
    res.render('index');
});

app.get("/code", (req, res)=>{
    res.status(200);
    
    res.render('code');
});

app.get("/login", (req, res)=>{
    res.status(200);
    res.render('login');
});

app.get("/cart", (req, res)=>{
    res.status(301);
    res.redirect("/code");
});

app.get("/signup", (req, res)=>{
    res.status(200);
    res.render('signup');
});
// app.get("/shop", (req, res)=>{
//     res.status(200);
//     res.render('shop');
// });

app.use(express.urlencoded({extended: true}));


app.post('/cartAdi', (req, res)=>{
    console.log(req.body);
    const { gameName, price, imageUrl } = req.body;
    // var neworder = Order({ gameName, price, imageUrl });

    var order = Order(req.body);
    order.save()
        
        .catch((err)=>{});
});
 


app.post('/register', (req, res)=>{
    console.log(req.body);
    var user = User(req.body);
    user.save()
        .then((result)=>{
            res.redirect("/");
        })
        .catch((err)=>{});
});
 


app.use((req, res)=>{
    res.status(404);
    //res.sendFile("./Views/not_found.html", {root: __dirname});
    res.render('not_found');
});