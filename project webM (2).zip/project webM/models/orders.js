const { request } = require("express");
const mongoose = require("mongoose");
const schema = mongoose.Schema


const orderSchema = new schema({
    gameName:{
        type: String,
        required: true
    
    },
     price:{
        type:Number,
        required: true

    },

    imageUrl:{
        type : String,
        required: true

    },
   
},{timestamps:true})

const order = mongoose.model("orders",orderSchema);



module.exports = order
