const { request } = require("express");
const mongoose = require("mongoose");
const schema = mongoose.Schema
const userSchema = new schema({
    email:{
        type: String,
        required: true
    },
    password:{
        type:String,
        required:true
    },
    address:{
        type:String,
        required: true
    }
},{timestamps:true})



const user = mongoose.model("users",userSchema);

module.exports = user

